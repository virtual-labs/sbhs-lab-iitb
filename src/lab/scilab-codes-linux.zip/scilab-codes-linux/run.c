#include "stdlib.h"

void main() {
    // Following code is duct-tape code.
    // This is done because directory structure is not fixed
    // and minimal libraries have to be used.
    // One of following 5 works. Rest will give error in command line.
    // C program will go unterminated
    system("python ../common_files/sbhsclient.py");
    system("python ../../common_files/sbhsclient.py");
    system("python ../../../common_files/sbhsclient.py");
    system("python ../../../../common_files/sbhsclient.py");
    system("python ../../../../../common_files/sbhsclient.py");
}

// Compile on 32-bit machine with command
// gcc run.c -L/usr/lib/gcc/i686-linux-gnu/4.6/libstdc++.so
